<div>
    <p class="submit"><input type="submit" name="save" class="button button-primary"
                             value="<?php echo esc_attr( _x( 'Create', 'create_page', WPAUTOTERMS_SLUG ) ); ?>"/></p>
</div>
